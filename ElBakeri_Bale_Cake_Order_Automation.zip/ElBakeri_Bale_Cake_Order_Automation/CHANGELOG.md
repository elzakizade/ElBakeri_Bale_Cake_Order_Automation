# Changelog

## 1.0.0
- Added the ElBakeri Bale cake and sweets order assistant workflow.
- Added Persian-language conversation instructions for wet sweets, dry sweets, and cakes.
- Added cake weight estimation based on guest count.
- Added image generation and Bale photo-delivery branches.
- Added administrator order notification.
- Sanitized bot-token URLs and administrator chat ID for repository sharing.
- Removed source-instance credential binding and instance fingerprint from the GitHub copy.
