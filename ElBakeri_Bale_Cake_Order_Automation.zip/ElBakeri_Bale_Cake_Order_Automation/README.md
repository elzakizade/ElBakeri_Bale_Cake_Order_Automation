# ElBakeri – Bale Cake & Sweets Order Automation

An n8n workflow for a Persian-language bakery assistant on Bale. It receives customer messages, guides customers through cake or sweets orders, estimates cake weight from guest count, requests a cake image from an image-generation API, sends the result to the customer, and notifies the bakery administrator.

> **Status:** Workflow template. Import and configure credentials, agent selection, Bale webhook, and administrator details before activation. The workflow has not been verified against your live Bale and GapGPT accounts.

## Features

- Receives incoming Bale messages through an n8n Webhook (`POST`).
- Extracts the customer's message and basic sender details.
- Uses an n8n AI Agent to conduct a short, Persian-language order conversation.
- Supports separate conversation paths for:
  - Wet sweets
  - Dry sweets
  - Cakes
- For cake orders, collects:
  1. Number of guests
  2. Cake flavor
  3. Design/theme
- Estimates cake weight at approximately **120–150 g per guest**.
- Generates an image prompt after the required cake details are collected.
- Calls the configured image-generation endpoint and handles either a returned image URL or base64 image data.
- Sends the generated cake image to the customer through Bale.
- Sends a new-order notification to the bakery administrator.

## Workflow architecture

```text
Bale Webhook
    |
Extract Bale Message
    |
Ask Persona Agent
    |
Parse Image Marker
    |------------------------------|
    |                              |
Reply to Customer              Order Complete?
                                   |
                              Generate Cake Image
                                   |
                              Extract Generated Image
                                   |
                                Image Ready?
                               /           \
                         Image URL       Base64 image
                             |               |
                       Send Photo URL   Send Photo
                                   |
                         Notify Bakery Admin
```

## Repository structure

```text
.
├── README.md
├── README_FA.md
├── SECURITY.md
├── CHANGELOG.md
├── .gitignore
├── docs/
│   ├── WORKFLOW_OVERVIEW.md
│   └── SETUP_FA.md
└── workflows/
    └── ElBakeri_Bale_FAST_Sweets_Cake_Image_FIXED.json
```

## Requirements

- An n8n instance with Webhook, Code, IF, HTTP Request, and AI Agent-related nodes available.
- A Bale bot and its API token.
- An n8n AI Agent configured with the ElBakeri bakery-assistant instructions.
- A valid GapGPT image-generation API credential compatible with the configured HTTP Request node.
- The administrator's Bale chat ID.

## Import and configuration

1. In n8n, choose **Workflows → Import from File** and select the JSON file in `workflows/`.
2. Open **Ask Persona Agent** and select the correct ElBakeri agent in your n8n instance. The agent reference in an exported workflow may not resolve in another instance.
3. Open **Generate Cake Image - GapGPT** and select/create the appropriate HTTP credential for your GapGPT account.
4. In the five Bale API HTTP Request nodes, replace `YOUR_BALE_BOT_TOKEN` in the endpoint URL with your bot token:
   - `Reply to Customer in Bale`
   - `Send Cake Photo in Bale`
   - `Image Failure Notice`
   - `Notify Bakery Admin`
   - `Send Cake Photo URL in Bale`
5. In **Notify Bakery Admin**, replace `YOUR_ADMIN_CHAT_ID` with the administrator's Bale chat ID.
6. Open **Bale Webhook**, copy its **Production URL**, and configure your Bale bot to send updates to that URL.
7. Test the workflow with a private test conversation. Confirm ordinary text replies, a complete cake order, image generation, photo delivery, and administrator notification.
8. Activate the workflow only after the live tests succeed.

For detailed Persian setup notes, see [`docs/SETUP_FA.md`](docs/SETUP_FA.md).

## Important configuration notes

- The exported workflow is **inactive** by default.
- The workflow JSON contains placeholders instead of the original Bale bot token and administrator chat ID.
- The source n8n AI Agent and GapGPT credential are instance-specific. Re-select them after import.
- The configured image endpoint is `https://api.gapgpt.app/v1/images/generations`, with model `gpt-image-1`. Confirm that your GapGPT account supports this endpoint, model, request format, and response format.
- The conversation prompt asks the AI Agent to emit internal `ORDER_SUMMARY` and `CAKE_IMAGE_PROMPT` markers when a cake order is ready. The parser depends on those marker names and format.
- Product availability, inventory, and prices are not connected to a live catalog in this template. Do not let the assistant invent prices or stock information.

## Security

Never commit real bot tokens, API keys, credentials, private customer data, or production webhook secrets. Use n8n credentials wherever possible. Review [`SECURITY.md`](SECURITY.md) before publishing or sharing this repository.

## License

No license is included. Add a license only if you have the right to grant reuse of this workflow and its associated prompt/content.
