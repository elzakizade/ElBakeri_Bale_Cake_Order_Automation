# Security policy

## Do not publish secrets
Never commit:
- Bale bot tokens
- GapGPT or other image-generation API keys
- n8n credential exports
- Production webhook secrets
- Customer messages, phone numbers, addresses, or order records

## This repository template
The workflow JSON has been sanitized:
- Bale API token paths use `YOUR_BALE_BOT_TOKEN`.
- The administrator chat ID uses `YOUR_ADMIN_CHAT_ID`.
- The source n8n instance fingerprint was removed.
- The source GapGPT credential binding was removed so a credential can be selected after import.

## If a token was exposed
If a real token was committed or otherwise shared outside a trusted secret store, revoke/rotate it with the provider and update the n8n workflow. Removing a token from the latest commit does not remove it from Git history.

## Before each commit
Review the changed files and search for strings such as `bot<token>`, `Bearer`, `api_key`, `password`, and real chat IDs. Keep repositories private if the workflow contains business logic that should not be public.
