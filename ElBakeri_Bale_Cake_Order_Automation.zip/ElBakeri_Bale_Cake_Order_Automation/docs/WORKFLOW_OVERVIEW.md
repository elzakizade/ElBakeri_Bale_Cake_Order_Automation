# Workflow overview

## Main path
1. **Bale Webhook** receives a POST update.
2. **Extract Bale Message** reads `message` or `edited_message`, then extracts chat ID, text, first name, and username.
3. **Ask Persona Agent** sends the customer message and the bakery conversation policy to the configured n8n AI Agent.
4. **Parse Image Marker** separates customer-facing text from the internal order and image markers.
5. **Reply to Customer in Bale** sends the cleaned text to the customer.

## Cake-image branch
When the parser detects a non-empty `CAKE_IMAGE_PROMPT` marker:
1. **Order Complete?** routes the completed cake order to image generation.
2. **Generate Cake Image - GapGPT** calls the configured image endpoint.
3. **Extract Generated Image** checks for base64 or URL output.
4. **Image Ready?** routes successful and unsuccessful responses.
5. The URL branch sends the URL using Bale `sendPhoto`; the binary branch sends the image as multipart data.
6. **Notify Bakery Admin** sends an order notification to the configured administrator chat.

## Important behavior
- The parser expects the AI Agent output to contain the exact markers `<<ORDER_SUMMARY: ...>>` and `<<CAKE_IMAGE_PROMPT: ...>>`.
- If the Agent changes or omits these markers, the image branch may not run.
- The webhook extraction code currently handles `message` and `edited_message`; it does not implement callback-query/button handling.
- The workflow is exported inactive.
